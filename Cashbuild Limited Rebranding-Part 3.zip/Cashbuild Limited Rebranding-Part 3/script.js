
document.addEventListener('DOMContentLoaded', function() {
    console.log('Cashbuild JavaScript loaded successfully!');
    
    // Initialize all functionality
    initNavigation();
    initMobileMenu();
    initProductFiltering();
    initFAQAccordion();
    initContactForm();
    initReviewSystem();
    initNewsletter();
    initBackToTop();
    initNotifications();
    initImageGalleries();
    initSmoothScrolling();
    initPageAnimations();
});

// 1. Navigation Active State
function initNavigation() {
    const navItems = document.querySelectorAll('nav ul li a');
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    
    navItems.forEach(item => {
        const itemHref = item.getAttribute('href');
        if (itemHref === currentPage) {
            item.parentElement.classList.add('active');
        }
        
        // Add click event for single page navigation
        item.addEventListener('click', function(e) {
            if (this.getAttribute('href').startsWith('#')) {
                e.preventDefault();
                const targetId = this.getAttribute('href').substring(1);
                const targetElement = document.getElementById(targetId);
                if (targetElement) {
                    targetElement.scrollIntoView({ behavior: 'smooth' });
                }
            }
        });
    });
}

// 2. Mobile Menu Toggle
function initMobileMenu() {
    const mobileToggle = document.querySelector('.mobile-toggle');
    const nav = document.querySelector('nav ul');
    
    if (mobileToggle) {
        mobileToggle.addEventListener('click', function() {
            nav.classList.toggle('show');
            this.classList.toggle('active');
        });
    }
    
    // Close mobile menu when clicking on a link
    const navLinks = document.querySelectorAll('nav ul li a');
    navLinks.forEach(link => {
        link.addEventListener('click', function() {
            if (nav.classList.contains('show')) {
                nav.classList.remove('show');
                if (mobileToggle) {
                    mobileToggle.classList.remove('active');
                }
            }
        });
    });
}

// 3. Product Filtering
function initProductFiltering() {
    const categoryTabs = document.querySelectorAll('.category-tabs .tab');
    const productCards = document.querySelectorAll('.product-card');
    
    if (categoryTabs.length === 0) return;
    
    categoryTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            // Remove active class from all tabs
            categoryTabs.forEach(t => t.classList.remove('active'));
            
            // Add active class to clicked tab
            this.classList.add('active');
            
            const category = this.getAttribute('data-category');
            
            // Show/hide products based on category
            productCards.forEach(card => {
                if (category === 'all' || card.getAttribute('data-category') === category) {
                    card.style.display = 'block';
                    // Add fade-in animation
                    card.style.animation = 'fadeIn 0.5s ease-in';
                } else {
                    card.style.display = 'none';
                }
            });
            
            console.log(`Filtering products by category: ${category}`);
        });
    });
}

// 4. FAQ Accordion
function initFAQAccordion() {
    const faqItems = document.querySelectorAll('.faq-item');
    
    if (faqItems.length === 0) return;
    
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        
        question.addEventListener('click', function() {
            // Toggle active class on clicked item
            const isActive = item.classList.contains('active');
            
            // Close all items first
            faqItems.forEach(otherItem => {
                otherItem.classList.remove('active');
            });
            
            // Open clicked item if it wasn't active
            if (!isActive) {
                item.classList.add('active');
            }
        });
    });
}

// 5. Contact Form with Validation
function initContactForm() {
    const contactForm = document.getElementById('contact-form');
    
    if (!contactForm) return;
    
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Reset previous errors
        clearFormErrors(contactForm);
        
        // Get form values
        const formData = new FormData(contactForm);
        const name = formData.get('name')?.trim() || '';
        const email = formData.get('email')?.trim() || '';
        const phone = formData.get('phone')?.trim() || '';
        const subject = formData.get('subject') || '';
        const message = formData.get('message')?.trim() || '';
        
        let isValid = true;
        
        // Validate name
        if (name === '') {
            showFormError('name', 'Please enter your full name');
            isValid = false;
        }
        
        // Validate email
        if (email === '') {
            showFormError('email', 'Please enter your email address');
            isValid = false;
        } else if (!isValidEmail(email)) {
            showFormError('email', 'Please enter a valid email address');
            isValid = false;
        }
        
        // Validate subject
        if (subject === '') {
            showFormError('subject', 'Please select a subject');
            isValid = false;
        }
        
        // Validate message
        if (message === '') {
            showFormError('message', 'Please enter your message');
            isValid = false;
        } else if (message.length < 10) {
            showFormError('message', 'Message must be at least 10 characters long');
            isValid = false;
        }
        
        // If form is valid, submit it
        if (isValid) {
            // Show loading state
            const submitBtn = contactForm.querySelector('button[type="submit"]');
            const originalText = submitBtn.textContent;
            submitBtn.innerHTML = '<div class="loading"></div> Sending...';
            submitBtn.disabled = true;
            
            // Simulate form submission
            setTimeout(() => {
                // In a real application, you would send the data to a server here
                console.log('Form submitted successfully:', { name, email, phone, subject, message });
                
                // Show success message
                showNotification('Thank you for your message! We will get back to you soon.', 'success');
                
                // Reset form
                contactForm.reset();
                
                // Restore button
                submitBtn.textContent = originalText;
                submitBtn.disabled = false;
            }, 2000);
        }
    });
}

// 6. Customer Reviews System
function initReviewSystem() {
    const reviewForm = document.getElementById('review-form');
    const reviewsList = document.getElementById('reviews-list');
    
    if (!reviewForm || !reviewsList) return;
    
    // Load existing reviews from localStorage
    loadReviews();
    
    reviewForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Get form values
        const name = document.getElementById('review-name')?.value.trim() || '';
        const rating = document.getElementById('review-rating')?.value || '5';
        const text = document.getElementById('review-text')?.value.trim() || '';
        
        // Validate form
        if (name === '' || text === '') {
            showNotification('Please fill in all fields', 'error');
            return;
        }
        
        // Create review object
        const review = {
            id: Date.now(), // Simple unique ID
            name: name,
            rating: parseInt(rating),
            text: text,
            date: new Date().toLocaleDateString('en-US', { 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
            })
        };
        
        // Save review
        saveReview(review);
        
        // Add review to display
        displayReview(review);
        
        // Reset form
        reviewForm.reset();
        
        // Show success message
        showNotification('Thank you for your review!', 'success');
        
        console.log('Review submitted:', review);
    });
}

// 7. Newsletter Subscription
function initNewsletter() {
    const newsletterForm = document.getElementById('newsletter-form');
    
    if (!newsletterForm) return;
    
    newsletterForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const emailInput = document.getElementById('newsletter-email');
        const email = emailInput.value.trim();
        
        // Validate email
        if (email === '') {
            showNotification('Please enter your email address', 'error');
            return;
        }
        
        if (!isValidEmail(email)) {
            showNotification('Please enter a valid email address', 'error');
            return;
        }
        
        // Show loading state
        const submitBtn = newsletterForm.querySelector('button[type="submit"]');
        const originalText = submitBtn.textContent;
        submitBtn.innerHTML = '<div class="loading"></div> Subscribing...';
        submitBtn.disabled = true;
        
        // Simulate API call
        setTimeout(() => {
            // Save to localStorage to simulate database
            let subscribers = JSON.parse(localStorage.getItem('cashbuildSubscribers')) || [];
            subscribers.push({
                email: email,
                date: new Date().toISOString()
            });
            localStorage.setItem('cashbuildSubscribers', JSON.stringify(subscribers));
            
            // Show success message
            showNotification('Thank you for subscribing to our newsletter!', 'success');
            
            // Reset form
            newsletterForm.reset();
            
            // Restore button
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
            
            console.log('Newsletter subscription:', email);
        }, 1500);
    });
}

// 8. Back to Top Button
function initBackToTop() {
    const backToTopButton = document.getElementById('back-to-top');
    
    if (!backToTopButton) return;
    
    window.addEventListener('scroll', function() {
        if (window.pageYOffset > 300) {
            backToTopButton.classList.add('show');
        } else {
            backToTopButton.classList.remove('show');
        }
    });
    
    backToTopButton.addEventListener('click', function() {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
}

// 9. Notification System
function initNotifications() {
    // This function initializes any notification triggers on the page
    // Notifications are primarily triggered by other functions
}

// 10. Image Galleries and Lightboxes
function initImageGalleries() {
    const galleryItems = document.querySelectorAll('.gallery-item, .product-image, .news-image');
    
    galleryItems.forEach(item => {
        item.addEventListener('click', function() {
            const imgSrc = this.querySelector('img')?.src || this.src;
            if (imgSrc) {
                openLightbox(imgSrc);
            }
        });
    });
    
    // Create lightbox HTML if it doesn't exist
    if (!document.getElementById('lightbox')) {
        const lightboxHTML = `
            <div id="lightbox" class="lightbox">
                <span class="lightbox-close">&times;</span>
                <img class="lightbox-content" id="lightbox-img">
                <div class="lightbox-caption"></div>
            </div>
        `;
        document.body.insertAdjacentHTML('beforeend', lightboxHTML);
        
        // Add lightbox event listeners
        const lightbox = document.getElementById('lightbox');
        const lightboxClose = document.querySelector('.lightbox-close');
        
        lightboxClose.addEventListener('click', closeLightbox);
        lightbox.addEventListener('click', function(e) {
            if (e.target === lightbox) {
                closeLightbox();
            }
        });
        
        // Close lightbox with ESC key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && lightbox.style.display === 'block') {
                closeLightbox();
            }
        });
    }
}

// 11. Smooth Scrolling for Anchor Links
function initSmoothScrolling() {
    const anchorLinks = document.querySelectorAll('a[href^="#"]');
    
    anchorLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href').substring(1);
            const targetElement = document.getElementById(targetId);
            
            if (targetElement) {
                const headerHeight = document.querySelector('header')?.offsetHeight || 0;
                const targetPosition = targetElement.offsetTop - headerHeight - 20;
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });
}

// 12. Page Animations
function initPageAnimations() {
    // Add CSS for animations if not already present
    if (!document.querySelector('#cashbuild-animations')) {
        const animationCSS = `
            <style id="cashbuild-animations">
                @keyframes fadeIn {
                    from { opacity: 0; transform: translateY(20px); }
                    to { opacity: 1; transform: translateY(0); }
                }
                
                @keyframes spin {
                    to { transform: rotate(360deg); }
                }
                
                .loading {
                    display: inline-block;
                    width: 16px;
                    height: 16px;
                    border: 2px solid rgba(255,255,255,.3);
                    border-radius: 50%;
                    border-top-color: #fff;
                    animation: spin 1s ease-in-out infinite;
                    margin-right: 8px;
                }
                
                .fade-in {
                    animation: fadeIn 0.6s ease-in;
                }
                
                .lightbox {
                    display: none;
                    position: fixed;
                    z-index: 1000;
                    left: 0;
                    top: 0;
                    width: 100%;
                    height: 100%;
                    background-color: rgba(0,0,0,0.9);
                }
                
                .lightbox-content {
                    margin: auto;
                    display: block;
                    width: 80%;
                    max-width: 700px;
                    max-height: 80%;
                    position: absolute;
                    top: 50%;
                    left: 50%;
                    transform: translate(-50%, -50%);
                }
                
                .lightbox-close {
                    position: absolute;
                    top: 15px;
                    right: 35px;
                    color: #f1f1f1;
                    font-size: 40px;
                    font-weight: bold;
                    cursor: pointer;
                    z-index: 1001;
                }
                
                .lightbox-close:hover {
                    color: #bbb;
                }
            </style>
        `;
        document.head.insertAdjacentHTML('beforeend', animationCSS);
    }
    
    // Add fade-in animation to elements when they come into view
    const animateElements = document.querySelectorAll('.product-card, .service-card, .value-card, .stat-card');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('fade-in');
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.1 });
    
    animateElements.forEach(element => {
        observer.observe(element);
    });
}

// ===== HELPER FUNCTIONS =====

// Form Validation Helpers
function showFormError(fieldName, message) {
    const field = document.querySelector(`[name="${fieldName}"]`);
    if (!field) return;
    
    let errorElement = field.parentNode.querySelector('.error-message');
    if (!errorElement) {
        errorElement = document.createElement('div');
        errorElement.className = 'error-message';
        field.parentNode.appendChild(errorElement);
    }
    
    errorElement.textContent = message;
    errorElement.style.color = '#e74c3c';
    errorElement.style.fontSize = '0.9em';
    errorElement.style.marginTop = '5px';
    
    field.style.borderColor = '#e74c3c';
}

function clearFormErrors(form) {
    const errorMessages = form.querySelectorAll('.error-message');
    errorMessages.forEach(error => error.remove());
    
    const formInputs = form.querySelectorAll('input, textarea, select');
    formInputs.forEach(input => {
        input.style.borderColor = '';
    });
}

function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Review System Helpers
function saveReview(review) {
    let reviews = JSON.parse(localStorage.getItem('cashbuildReviews')) || [];
    reviews.unshift(review); // Add new review at the beginning
    localStorage.setItem('cashbuildReviews', JSON.stringify(reviews));
}

function loadReviews() {
    const reviewsList = document.getElementById('reviews-list');
    if (!reviewsList) return;
    
    const reviews = JSON.parse(localStorage.getItem('cashbuildReviews')) || [];
    
    if (reviews.length === 0) {
        reviewsList.innerHTML = '<div class="no-reviews"><i class="far fa-comments"></i><h3>No Reviews Yet</h3><p>Be the first to share your experience with Cashbuild!</p></div>';
        return;
    }
    
    reviewsList.innerHTML = '';
    reviews.forEach(review => {
        displayReview(review);
    });
}

function displayReview(review) {
    const reviewsList = document.getElementById('reviews-list');
    if (!reviewsList) return;
    
    const reviewElement = document.createElement('div');
    reviewElement.className = 'review-card';
    reviewElement.setAttribute('data-id', review.id);
    
    // Create rating stars
    let stars = '';
    for (let i = 1; i <= 5; i++) {
        if (i <= review.rating) {
            stars += '★';
        } else {
            stars += '☆';
        }
    }
    
    reviewElement.innerHTML = `
        <div class="review-rating">${stars}</div>
        <div class="review-text">${escapeHtml(review.text)}</div>
        <div class="review-author">— ${escapeHtml(review.name)}</div>
        <div class="review-date">${review.date}</div>
        <button class="btn btn-outline delete-review" data-id="${review.id}">Delete Review</button>
    `;
    
    reviewsList.appendChild(reviewElement);
    
    // Add event listener to delete button
    const deleteButton = reviewElement.querySelector('.delete-review');
    deleteButton.addEventListener('click', function() {
        if (confirm('Are you sure you want to delete this review?')) {
            deleteReview(review.id);
            reviewElement.remove();
            showNotification('Review deleted successfully', 'success');
        }
    });
}

function deleteReview(id) {
    let reviews = JSON.parse(localStorage.getItem('cashbuildReviews')) || [];
    reviews = reviews.filter(review => review.id !== id);
    localStorage.setItem('cashbuildReviews', JSON.stringify(reviews));
}

// Notification Helper
function showNotification(message, type = 'info') {
    // Remove existing notifications
    const existingNotifications = document.querySelectorAll('.cashbuild-notification');
    existingNotifications.forEach(notification => notification.remove());
    
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `cashbuild-notification ${type}`;
    notification.textContent = message;
    
    // Style the notification
    notification.style.position = 'fixed';
    notification.style.top = '20px';
    notification.style.right = '20px';
    notification.style.padding = '15px 25px';
    notification.style.borderRadius = '8px';
    notification.style.zIndex = '10000';
    notification.style.maxWidth = '400px';
    notification.style.boxShadow = '0 5px 15px rgba(0,0,0,0.2)';
    notification.style.transform = 'translateX(150%)';
    notification.style.transition = 'transform 0.3s ease';
    
    if (type === 'success') {
        notification.style.background = '#d4edda';
        notification.style.color = '#155724';
        notification.style.border = '1px solid #c3e6cb';
    } else if (type === 'error') {
        notification.style.background = '#f8d7da';
        notification.style.color = '#721c24';
        notification.style.border = '1px solid #f5c6cb';
    } else {
        notification.style.background = '#d1ecf1';
        notification.style.color = '#0c5460';
        notification.style.border = '1px solid #bee5eb';
    }
    
    // Add to page
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Remove after 5 seconds
    setTimeout(() => {
        notification.style.transform = 'translateX(150%)';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 300);
    }, 5000);
    
    // Allow manual dismissal
    notification.addEventListener('click', function() {
        this.style.transform = 'translateX(150%)';
        setTimeout(() => {
            if (this.parentNode) {
                this.remove();
            }
        }, 300);
    });
}

// Lightbox Functions
function openLightbox(imgSrc) {
    const lightbox = document.getElementById('lightbox');
    const lightboxImg = document.getElementById('lightbox-img');
    
    if (lightbox && lightboxImg) {
        lightboxImg.src = imgSrc;
        lightbox.style.display = 'block';
        
        // Prevent body scroll
        document.body.style.overflow = 'hidden';
    }
}

function closeLightbox() {
    const lightbox = document.getElementById('lightbox');
    if (lightbox) {
        lightbox.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
}

// Utility Functions
function escapeHtml(unsafe) {
    return unsafe
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

// Export functions for use in other files (if using modules)
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        initNavigation,
        initProductFiltering,
        initFAQAccordion,
        initContactForm,
        initReviewSystem,
        showNotification,
        isValidEmail
    };
}
document.getElementById('contactForm').addEventListener('submit', function(event) {
  event.preventDefault(); // prevent page reload

  emailjs.sendForm('YOUR_SERVICE_ID', 'YOUR_TEMPLATE_ID', this)
    .then(function() {
      alert('Message sent successfully! We will get back to you soon.');
      document.getElementById('contactForm').reset();
    }, function(error) {
      alert('Oops... Something went wrong. Please try again later.');
      console.error('EmailJS error:', error);
    });
});

document.getElementById('cancelBtn').addEventListener('click', function() {
    // Option 1: Reset the form fields
    document.getElementById('contactForm').reset();

    // Option 2 (optional): Go back to previous page
    // window.history.back();
});

document.getElementById("contactForm").addEventListener("submit", function(e){
    let name = document.getElementById("name").value.trim();
    let email = document.getElementById("email").value.trim();
    let message = document.getElementById("message").value.trim();

    if(name === "" || email === "" || message === ""){
        alert("Please fill in all fields");
        e.preventDefault();
        return;
    }

    let emailCheck = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if(!emailCheck.test(email)){
        alert("Enter a valid email");
        e.preventDefault();
    }
});

function sendMail() {
  emailjs.send("service_id", "template_id", {
    from_name: document.getElementById("name").value,
    reply_to: document.getElementById("email").value,
    message: document.getElementById("message").value
  }).then(() => {
    alert("Message sent!");
  });
}

// Product Data
const productData = {

    kitchen: [
        { name: "Kitchen Sink", price: "R499" },
        { name: "Wall Tiles", price: "R249" },
        { name: "Cupboard Handle Set", price: "R89" }
    ],

    bathroom: [
        { name: "Shower Head", price: "R199" },
        { name: "Bathroom Tiles", price: "R349" },
        { name: "Towel Rail", price: "R159" }
    ],

    bedroom: [
        { name: "Wardrobe", price: "R1299" },
        { name: "Ceiling Paint", price: "R199" },
        { name: "Bed Frame", price: "R1699" }
    ],

    livingroom: [
        { name: "Light Fitting", price: "R299" },
        { name: "Wall Panels", price: "R499" },
        { name: "Floor Laminates", price: "R799" }
    ]

};


// Show category products
function showProducts(category) {
    document.getElementById("products").classList.add("hidden");
    document.getElementById("product-details").classList.remove("hidden");

    document.getElementById("product-title").textContent =
        category.charAt(0).toUpperCase() + category.slice(1) + " Products";

    const grid = document.getElementById("product-grid");
    grid.innerHTML = "";

    productData[category].forEach(item => {
        grid.innerHTML += `
            <div class="product-card">
                <h4>${item.name}</h4>
                <p>${item.price}</p>
            </div>
        `;
    });
}

// Back to categories
function backToCategories() {
    document.getElementById("products").classList.remove("hidden");
    document.getElementById("product-details").classList.add("hidden");
}
document.getElementById('enquiryForm').addEventListener('submit', function(e) {
    e.preventDefault();

    let valid = true;

    // Get fields
    let name = document.getElementById('name');
    let email = document.getElementById('email');
    let phone = document.getElementById('phone');
    let message = document.getElementById('message');

    let successMsg = document.getElementById('successMsg');

    // Reset messages
    document.querySelectorAll('.error').forEach(e => e.textContent = "");

    // Name validation
    if (name.value.trim().length < 3) {
        document.getElementById('nameError').textContent = "Name must be at least 3 characters.";
        valid = false;
    }

    // Email validation
    if (!email.value.includes("@") || !email.value.includes(".")) {
        document.getElementById('emailError').textContent = "Please enter a valid email.";
        valid = false;
    }

    // Phone validation (must be numbers only)
    if (!/^[0-9]{10}$/.test(phone.value)) {
        document.getElementById('phoneError').textContent = "Phone number must be 10 digits.";
        valid = false;
    }

    // Message validation
    if (message.value.trim().length < 10) {
        document.getElementById('messageError').textContent = "Message must be at least 10 characters.";
        valid = false;
    }

    // If valid
    if (valid) {
        successMsg.textContent = "Your enquiry has been successfully submitted!";
        successMsg.style.color = "green";

        // Clear form
        name.value = "";
        email.value = "";
        phone.value = "";
        message.value = "";
    }
});
document.getElementById('contact-form').addEventListener('submit', function(e) {
    e.preventDefault();

    // Get form values
    let name = document.getElementById('name').value.trim();
    let email = document.getElementById('email').value.trim();
    let message = document.getElementById('message').value.trim();
    let responseMsg = document.getElementById('response-message');

    // Validation
    if (name === "" || email === "" || message === "") {
        responseMsg.textContent = "Please fill in all fields.";
        responseMsg.style.color = "red";
        return;
    }

    if (!email.includes("@") || !email.includes(".")) {
        responseMsg.textContent = "Please enter a valid email address.";
        responseMsg.style.color = "red";
        return;
    }

    // Simulated processing (no backend)
    setTimeout(() => {
        responseMsg.textContent = "Thank you! Your enquiry has been received.";
        responseMsg.style.color = "green";

        // Clear form after success
        document.getElementById('contact-form').reset();
    }, 800);
});

document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("contactForm");
    const successMessage = document.getElementById("successMessage");

    form.addEventListener("submit", function (e) {
        e.preventDefault();

        let isValid = true;

        // Full Name
        const name = document.getElementById("name");
        const nameError = name.nextElementSibling;

        if (name.value.trim() === "") {
            nameError.textContent = "Please enter your full name";
            isValid = false;
        } else {
            nameError.textContent = "";
        }

        // Email
        const email = document.getElementById("email");
        const emailError = email.nextElementSibling;

        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!emailPattern.test(email.value)) {
            emailError.textContent = "Please enter a valid email address";
            isValid = false;
        } else {
            emailError.textContent = "";
        }

        // Message
        const message = document.getElementById("message");
        const messageError = message.nextElementSibling;

        if (message.value.trim().length < 5) {
            messageError.textContent = "Message must be at least 5 characters";
            isValid = false;
        } else {
            messageError.textContent = "";
        }

        // If everything is valid
        if (isValid) {
            successMessage.classList.remove("hidden");
            form.reset();

            setTimeout(() => {
                successMessage.classList.add("hidden");
            }, 3000);
        }
    });
});

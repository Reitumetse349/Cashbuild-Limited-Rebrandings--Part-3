# Changelog

### Added
- **Responsive design** for images and sections across different screen sizes.    
- **Shop Now button** on the home page linking to Products & Services.  
- Contact form styling with hover effects and input focus styles.  
- Review section with styled cards.  

### Changed
- Navigation bar styling unified across all pages.  
- Body background changed to **cream white**.  
- Header background now matches body (for clean layout).  
- Image sizes standardized (450px for desktop, scaled down for tablets/phones).
- I changed colors for the covers.
- I changed the the color for shop now icon to green.  

### Fixed
- Products & Services page images were misaligned — fixed with `.image-row` and CSS control.  
- News page formatting updated to match Products & Services layout.  
- Navigation links now consistent and working across all pages.  

### Added
- Initial project setup with plain **HTML & CSS**.  
- **Home page** with introduction and overview of Cashbuild.  
- **About Us** page with company history, mission, and vision.  
- **Products & Services** page with product categories and images.  
- **News page** with updates and promotions.  
- **Contact Us** page with form, store info, and location.  
- Basic header, navigation, and footer structure.  
- I changed the the text on sale from cement bags to Paints & Electronics.
- I added a new picture on about us and changed the format of the paragraphs.

### Recently Added
- I added a lightbox and slidethrough and click button
- I modified the 
- I split the product&services page into products page and also service page
- I added a cancel button in contact us.
- I added a responsive form
- Contact page enquiry form with fully functional controls (text fields, email validation, dropdown menu, textarea, and submit button).